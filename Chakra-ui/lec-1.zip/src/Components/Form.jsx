import { Box, Heading } from "@chakra-ui/react";

function Form() {
  return (
    <Box>
      <Heading>Form</Heading>
    </Box>
  );
}

export default Form;
