import AllRoutes from "./Routes/AllRoutes";
import "./styles.css";

export default function App() {
  return <AllRoutes />;
}
