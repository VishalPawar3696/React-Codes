import AfterRender from "./components/AfterRender";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <AfterRender />
    </div>
  );
}
