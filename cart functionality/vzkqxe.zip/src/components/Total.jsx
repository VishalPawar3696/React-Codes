import React from "react";

export default function Total({ total }) {
  return (
    <>
      <h2>Total:{total}</h2>
    </>
  );
}
