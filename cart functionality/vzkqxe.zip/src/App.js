import CartContainer from "./components/CartContainer";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Cart Functionality</h1>
      <CartContainer/>
      
    </div>
  );
}
