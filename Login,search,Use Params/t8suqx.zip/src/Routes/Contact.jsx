function Contact() {
  return <h3>Contact US</h3>;
}

export default Contact;
