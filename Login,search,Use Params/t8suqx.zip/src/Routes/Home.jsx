export default function Home() {
  return <h3>Home</h3>;
}
