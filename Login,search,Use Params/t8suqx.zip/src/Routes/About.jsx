export default function About() {
  return <h3>About</h3>;
}
