import Todo from "./components/Todo";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>TODO APP</h1>
      <Todo />
    </div>
  );
}
