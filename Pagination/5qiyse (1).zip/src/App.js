import TodoWithPagination from "./components/TodoWithPagination";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
    <TodoWithPagination/>
   
    </div>
  );
}
