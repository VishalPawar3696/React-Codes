

import Scroll from "./components/Scroll";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Scroll/>
    </div>
  );
}
