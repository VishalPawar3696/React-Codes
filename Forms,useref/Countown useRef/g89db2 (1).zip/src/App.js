import Timer from "./components/Timer";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Timer/>
    </div>
  );
}
