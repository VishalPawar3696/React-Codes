
import FocusLoad from "./components/FocusLoad";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <FocusLoad/>
    </div>
  );
}
